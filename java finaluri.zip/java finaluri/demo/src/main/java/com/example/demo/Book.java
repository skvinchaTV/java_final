package com.example.demo;

public class Book {
    private int pages;
    private String author;
    private String name;
    private double price;

    public Book(int pages, String author, String name, double price) {
        this.pages = pages;
        this.author = author;
        this.name = name;
        this.price = price;
    }

    public int getPages() {
        return pages;
    }

    public String getAuthor() {
        return author;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    @Override
    public String toString() {
        return "Book{" +
                "pages=" + pages +
                ", author='" + author + '\'' +
                ", name='" + name + '\'' +
                ", price=" + price +
                '}';
    }
}
