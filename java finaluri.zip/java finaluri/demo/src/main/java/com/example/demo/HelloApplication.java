package com.example.demo;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import java.io.IOException;
import java.sql.*;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

public class HelloApplication extends Application {

    private static String URL = "jdbc:mysql://localhost:3306/products";
    private static String USER = "root";
    private static String PASS = null;
    private static String QUERY = "select * from product";
    private static String INSERT_QUERY = "insert into product (name, price, author, pages) values (?,?,?,?)";

    @Override
    public void start(Stage stage) throws IOException {
        Label pLabel = new Label("Pages:");
        Label nLabel = new Label("name:");
        Label aLabel = new Label("author:");
        Label prLabel = new Label("price:");
        Button addButton = new Button("Add");
        Button pieButton = new Button("PieChart");

        TextField pTextField = new TextField();
        TextField nTextField = new TextField();
        TextField aTextField = new TextField();
        TextField prTextField = new TextField();

        GridPane gridPane = new GridPane();
        gridPane.addColumn(0, pLabel, pTextField);
        gridPane.addColumn(0, nLabel, nTextField);
        gridPane.addColumn(0, aLabel, aTextField);
        gridPane.addColumn(0, prLabel, prTextField);
        gridPane.addColumn(0, addButton, pieButton);

        addButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    Connection connection = DriverManager.getConnection(URL, USER, PASS);

                    int pages = Integer.parseInt(pTextField.getText());
                    String author = aTextField.getText();
                    String name = nTextField.getText();
                    double price = Double.parseDouble(prTextField.getText());

                    Book book = new Book(pages, author, name, price);


                    PreparedStatement preparedStatement = connection.prepareStatement(INSERT_QUERY);
                    preparedStatement.setString(1, book.getName());
                    preparedStatement.setDouble(2, book.getPrice());
                    preparedStatement.setString(3, book.getAuthor());
                    preparedStatement.setInt(4, book.getPages());
                    preparedStatement.execute();
                    System.out.println("added\n");

                    List<Book> books = List.of(new Book(pages, author, name, price));
                    List<Book> sotredBooks = books.stream()
                            .filter(a -> a.getPrice() < 100 && a.getPrice() > 0)
                            .toList();

                    sotredBooks.forEach(System.out::println);
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }

            }
        });
        pieButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    Connection connection = DriverManager.getConnection(URL, USER, PASS);
                    Statement statement = connection.createStatement();
                    ResultSet resultSet = statement.executeQuery(QUERY);

                    ObservableList<PieChart.Data> pieData = FXCollections.observableArrayList();
                    while(resultSet.next()){
                        String name = resultSet.getString("name");
                        double price = resultSet.getDouble("price");
                        pieData.add(new PieChart.Data(name, price));
                    }
                    PieChart pieChart = new PieChart(pieData);
                    gridPane.addColumn(0, pieChart);

                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
        });


        Scene scene = new Scene(gridPane, 600, 600);
        stage.setTitle("Hello!");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}